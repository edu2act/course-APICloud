示例基于玩转晋城修改，相关模型，以及数据可以参考 [玩转晋城](http://community.apicloud.com/bbs/forum.php?mod=viewthread&tid=291&highlight=o2o)
